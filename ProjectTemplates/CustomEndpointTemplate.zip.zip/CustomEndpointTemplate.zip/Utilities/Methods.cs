﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Aptify.Consulting.ProcessComponents.Utilities
{
    static class Methods
    {
        public static string SafeString(object o)
        {
            try
            {
                return Convert.ToString(o);
            }
            catch
            {
                return string.Empty;
            }
        }

        public static bool SafeBool(object o)
        {
            try
            {
                return Convert.ToBoolean(o);
            }
            catch
            {
                return false;
            }
        }

        public static long SafeLong(object o)
        {
            try
            {
                return Convert.ToInt64(o);
            }
            catch
            {
                return -1;
            }
        }

        public static double SafeDouble(object o)
        {
            try
            {
                return Convert.ToDouble(o);
            }
            catch
            {
                return -1;
            }
        }
    }
}
