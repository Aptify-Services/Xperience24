﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Aptify.Services.Framework.Endpoints;
using Aptify.Framework.DataServices;
using Aptify.Security.Provider.Factory;
using Aptify.Security.Provider.CredentialContainer;
using Aptify.Framework.Application;
using $safeprojectname$.Utilities;
using Newtonsoft.Json;
using System.Data;
using Aptify.Consulting.ProcessComponents.Utilities;

namespace $safeprojectname$
{
    public class CustomEndpoint : Aptify.Services.Framework.Endpoints.ServiceController
    {
        #region MainMethods
        public override ServiceResponse ProcessRequest(ServiceRequestContext context)
        {
            ServiceResponse response = new ServiceResponse();
            try
            {
                //  Set my user credentials using the latest way of doing it.
                UserCredentials uc;
                AuthenticatedContext ac = ServiceCredentialContainerFactory.Instance.GetAuthenticatedContext();
                if (ac != null)
                {
                    uc = ac.ContextUserCredentials.Clone(false);
                }
                else
                {
                    uc = ServiceApplicationCredentialFactory.Instance.GetServiceApplicationCredentails().Clone(false);
                }

                DataAction _oDA = new DataAction(uc);
                AptifyApplication _oApp = new AptifyApplication(uc);

                // Do some processing


                // Then return success. The success class can be changed to return anything we want.
                response.StatusCode = ServiceResponse.ResponseStatusCode.OK;
                response.Content = new StringContent(JsonConvert.SerializeObject(new Classes.SuccessClass()));
            }
            catch (Exception ex)
            {
                response.StatusCode = ServiceResponse.ResponseStatusCode.BadRequest;
                response.Content = new StringContent(JsonConvert.SerializeObject(new Classes.ErrorClass(ex.Message)));
                Aptify.Framework.ExceptionManagement.ExceptionManager.Publish(ex);
            }

            return response;
        }
        #endregion

        #region Helper
        /// <summary>
        /// Template for a database accessor method.
        /// </summary>
        /// <param name="EntityID"></param>
        /// <param name="RecordID"></param>
        /// <param name="_oDA"></param>
        /// <returns></returns>
        private Dictionary<string, string> GetStringDictionary(long EntityID, long RecordID, DataAction _oDA)
        {
            Dictionary<string, string> result = new Dictionary<string, string>();
            string SQL = "spGetStringDictionary__c";
            IDataParameter[] myParams = new IDataParameter[2];
            myParams[0] = _oDA.GetDataParameter("EntityID", System.Data.SqlDbType.BigInt, EntityID);
            myParams[1] = _oDA.GetDataParameter("RecordID", System.Data.SqlDbType.BigInt, RecordID);

            DataTable SQLResult = _oDA.GetDataTableParametrized(SQL, CommandType.StoredProcedure, myParams);

            foreach (DataRow row in SQLResult.Rows)
            {
                if (!result.ContainsKey(Methods.SafeString(row["TopicCodeID"])))
                {
                    result.Add("", "");
                }
            }
            return result;
        }
        #endregion
    }
}
