﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace $safeprojectname$ 
{
    /// <summary>
    /// All needed to do is include the object that will be overriden and start overriding and extending the class.
    /// Also will need to inherit the object.
    /// </summary>
    public class EntityPlugInGE : Aptify.Framework.BusinessLogic.GenericEntity.AptifyGenericEntity
    {

    }
}
