﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace $safeprojectname$.Utilities
{
    class Classes
    {
        public class ErrorClass
        {
            public string Status = "failure";
            public string Error = String.Empty;

            public ErrorClass(string err)
            {
                Error = err;
            }

            /// <summary>
            /// This simple method allow appending strings to the error class property.
            /// </summary>
            /// <param name="err">string to append to the main error.</param>
            public void AppendError(string err)
            {
                if (Error.Length == 0)
                {
                    Error = err;
                }
                else
                {
                    Error += "\n" + err;
                }
            }
        }

        public class SuccessClass
        {
            public string Status = "success";
        }
    }
}
